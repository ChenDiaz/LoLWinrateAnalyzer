$('#button-jquery').click(function(){
      $(this).css('background-color','red');
      $(this).html('Loading');
});