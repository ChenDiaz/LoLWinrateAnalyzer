# Solo / Duo
This web app, built with PHP and Bootstrap, calculates win rates of any North American League of Legends player with and without a specified duo partner on the ranked ladder.

![A demo of the app!](/css/img/ResultPage.jpg?raw=true "Demo")